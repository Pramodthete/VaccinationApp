package com.app.springrest.pojos;

public enum Role {
	USER,CENTER,ADMIN
}
