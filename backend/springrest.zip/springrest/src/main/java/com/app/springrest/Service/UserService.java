package com.app.springrest.Service;


public interface UserService {


}
